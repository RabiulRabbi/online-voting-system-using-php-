<?php include 'includes/session.php'; ?>

<?php
$conn = new mysqli('localhost', 'root', '', 'votesystem');

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
?>
<?php
if (isset($_POST['add'])) {
	$eId = $_SESSION['election_id'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];
	$filename = $_FILES['photo']['name'];
	if (!empty($filename)) {
		move_uploaded_file($_FILES['photo']['tmp_name'], '../images/' . $filename);
	}
	//generate voters id
	$set = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$voter = substr(str_shuffle($set), 0, 5);
	$set2 = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$password = substr(str_shuffle($set2), 0, 5);


	$sql = "INSERT INTO voters (election_id, voters_id, password, firstname, lastname, photo, email) VALUES ('$eId','$voter', '$password', '$firstname', '$lastname', '$filename', '$email')";
	if ($conn->query($sql)) {
		$_SESSION['success'] = 'Voter added successfully';


		// $to_email = $email;
		// $subject = "Online Voting System";
		// $body = "Dear " . $firstname . " " . $lastname . " " . "Your voting id & password is now available for voting " . "\n\nID: " . $voter . "\nPassword: " . $password;
		// $headers = "From: rabiulislam12360@gmail.com";

		// if (mail($to_email, $subject, $body, $headers)) {
		// 	echo "Email successfully sent to $to_email...";
		// } else {
		// 	echo "Email sending failed...";
		// }
	} else {
		$_SESSION['error'] = $conn->error;
	}
} else {
	$_SESSION['error'] = 'Fill up add form first';
}

header('location: voters.php');
