<?php
$conn = new mysqli('localhost', 'root', '', 'votesystem');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php

if (isset($_POST['add'])) {
    $eName = $_POST['election_name'];
    // $startTime = $_POST['start'];
    // $endTime = $_POST['end'];
    // $timezone = $_POST['timezone'];
    // //generate elections id
    $set = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $eId = substr(str_shuffle($set), 0, 10);

    //echo $startTime, $endTime, $timezone;


    $sql = "INSERT INTO election (election_id, election_name) VALUES ('$eId','$eName')";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Election added successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
} else {
    $_SESSION['error'] = 'Fill up add form first';
}

header('location: election.php');
