<?php
include 'includes/session.php';

if (isset($_POST['edit'])) {
	$id = $_POST['id'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];

	$sql = "SELECT * FROM voters WHERE id = $id";
	$query = $conn->query($sql);

	$sql = "UPDATE voters SET firstname = '$firstname', lastname = '$lastname' WHERE id = '$id'";
	if ($conn->query($sql)) {
		$_SESSION['success'] = 'Voter updated successfully';
	} else {
		$_SESSION['error'] = $conn->error;
	}
} else {
	$_SESSION['error'] = 'Fill up edit form first';
}

header('location: voters.php');
