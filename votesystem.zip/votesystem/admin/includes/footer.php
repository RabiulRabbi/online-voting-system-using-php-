<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>All rights reserved</b>
  </div>
  <strong>&copy; Copyright- <a href="#">Rabiul-Rakib</a></strong>
</footer>