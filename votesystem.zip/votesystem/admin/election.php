<?php include 'includes/session.php'; ?>
<?php include 'includes/slugify.php'; ?>
<?php include 'includes/header.php'; ?>

<body class="hold-transition skin-blue sidebar-mini" style="background-color: #d5d7db;">
    <?php include 'includes/navbar.php'; ?>
    <div>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <span style="font-size: 30px; font-weight: 700;">
                Election Dashboard
            </span>
            <a href="#addnew" style="float: right;" data-toggle="modal" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Create New Election</a>
            <!-- <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Voters</li>
            </ol> -->
        </section>
        <!-- Main content -->
        <section class="content container">
            <?php
            if (isset($_SESSION['error'])) {
                echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              " . $_SESSION['error'] . "
            </div>
          ";
                unset($_SESSION['error']);
            }
            if (isset($_SESSION['success'])) {
                echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              " . $_SESSION['success'] . "
            </div>
          ";
                unset($_SESSION['success']);
            }
            ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <!-- <div class="box-header with-border text-right">
                            <a href="#addnew" data-toggle="modal" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add New Voters</a>
                        </div> -->
                        <div class="box-body">
                            <table id="example1" class="table table-bordered">
                                <thead>
                                    <th>Election name</th>
                                    <!-- <th>Start time</th> -->
                                    <!-- <th>End time</th> -->
                                    <!-- <th>Timezone</th>
                                    <th>Tools</th> -->
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM election";
                                    // <td>" . $row['election_id'] . "</td>
                                    $query = $conn->query($sql);
                                    while ($row = $query->fetch_assoc()) {
                                        echo "
                                        <tr style='background-color: #d5d7db;'>
                                        <td style=\"color: #3C8DBC; font-weight: 700; font-size: 20px;\"> 
                                            <a href='../../votesystem/admin/home.php?election_id=" . $row['election_id'] . "' class='' data-id='" . $row['election_id'] . "'><i class='fa fa-arrow'></i> " . $row['election_name'] . " </a>
                                            <span style=\"float: right;\">
                                            <button class='btn btn-danger btn-sm delete' data-id='" . $row['id'] . "'><i class='fa fa-trash'></i> Delete</button>
                                            <a href='../../votesystem/admin/home.php?election_id=" . $row['election_id'] . "' class='btn btn-success btn-sm ' data-id='" . $row['election_id'] . "'><i class='fa fa-arrow'></i> Open>>></a>
                                            </span>
                                        </td>
                                        
                                        </tr>
                                    ";
                                    }
                                    ?>
                                    <!-- <td>" . $row['start_time'] . "</td>
                                    <td>" . $row['endtime'] . "</td>
                                        <td>" . $row['end_time'] . "</td>
                                        <td>" . $row['timezone'] . "</td> -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>



    </section>
    <!-- <?php include 'includes/footer.php'; ?> -->
    <?php include 'includes/election_modal.php'; ?>

    <?php include 'includes/scripts.php'; ?>
    <script>
        $(function() {

            $(document).on('click', '.delete', function(e) {
                e.preventDefault();
                $('#delete').modal('show');
                var id = $(this).data('id');
                console.log(id);
                getRow(id);
            });

        });

        function getRow(id) {
            $.ajax({
                type: 'POST',
                url: 'election_row.php',
                data: {
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    $('.id').val(response.id);
                    $('.fullname').html(response.election_name);
                }
            });
        }
    </script>

</body>

</html>