<?php include 'includes/session.php'; ?>

<?php
$conn = new mysqli('localhost', 'root', '', 'votesystem');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
if (isset($_POST['send'])) {
    $id = $_POST['id'];
    $sql = "SELECT * FROM voters WHERE id = '$id'";
    $query = $conn->query($sql);
    while ($row = $query->fetch_assoc()) {
        $firstname = $row['firstname'];
        $lastname = $row['lastname'];
        $email = $row['email'];
        $voter = $row['voters_id'];
        $password = $row['password'];
    }

    $to_email = $email;
    $subject = "Online Voting System";
    $body = "Dear" . $firstname . " " . $lastname . " " . "Your voting id & password is now available for voting " . "\n\nID: " . $voter . "\nPassword: " . $password;
    $headers = "From: onlinevoting86@gmail.com";

    if (mail($to_email, $subject, $body, $headers)) {
        echo "Email successfully sent to $to_email...";
    } else {
        echo "Email sending failed...";
    }
} else {
    $_SESSION['error'] = $conn->error;
}

header('location: voters.php');
