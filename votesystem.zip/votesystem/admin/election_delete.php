<?php
include 'includes/session.php';

if (isset($_POST['delete'])) {
    $eId = $_POST['id'];

    $sql = "DELETE FROM election WHERE id = '$eId'";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Candidate deleted successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
    $sql = "DELETE FROM voters WHERE election_id = '$eId'";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Candidate deleted successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
    $sql = "DELETE FROM positions WHERE election_id = '$eId'";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Candidate deleted successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
    $sql = "DELETE FROM candidates WHERE election_id = '$eId'";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Candidate deleted successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
    $sql = "DELETE FROM votes WHERE election_id = '$eId'";
    if ($conn->query($sql)) {
        $_SESSION['success'] = 'Election deleted successfully';
    } else {
        $_SESSION['error'] = $conn->error;
    }
} else {
    $_SESSION['error'] = 'Select item to delete first';
}
header('location: election.php');
