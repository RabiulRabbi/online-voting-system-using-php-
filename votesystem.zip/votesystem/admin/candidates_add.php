<?php include 'includes/session.php'; ?>

<?php
$conn = new mysqli('localhost', 'root', '', 'votesystem');

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
?>
<?php
if (isset($_POST['add'])) {
	$eId = $_SESSION['election_id'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$position = $_POST['position'];
	// $platform = $_POST['platform'];
	$filename = $_FILES['photo']['name'];
	if (!empty($filename)) {
		move_uploaded_file($_FILES['photo']['tmp_name'], '../images/' . $filename);
	}

	$sql = "INSERT INTO candidates (election_id, position_id, firstname, lastname, photo) VALUES ('$eId', '$position', '$firstname', '$lastname', '$filename')";
	if ($conn->query($sql)) {
		$_SESSION['success'] = 'Candidate added successfully';
	} else {
		$_SESSION['error'] = $conn->error;
	}
} else {
	$_SESSION['error'] = 'Fill up add form first';
}

header('location: candidates.php');
