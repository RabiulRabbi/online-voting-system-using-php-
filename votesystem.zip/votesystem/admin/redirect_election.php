<?php
include 'includes/session.php';


//$_SESSION['election_id'] = $_POST['id'];
header("location:http://localhost/votesystem/admin/home.php");
