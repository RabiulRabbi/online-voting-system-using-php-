<div class="header-navbar">
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand">Online Voting System</a>
            <a class="admin-login-btn" href="../../votesystem/admin/home.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Admin-Login</a>
        </div>
    </nav>
</div>