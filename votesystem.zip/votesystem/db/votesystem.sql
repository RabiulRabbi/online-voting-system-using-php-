-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2022 at 12:16 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votesystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `firstname`, `lastname`, `photo`, `created_on`) VALUES
(1, 'admin', '$2y$10$YrNLQies2WFF2tB2dvLSu.I3yf05mi/eAqI/.X1480bdUCGpHxvu6', 'Admin', '', 'vote.jpg', '2018-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `election_id` varchar(20) DEFAULT NULL,
  `position_id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `election_id`, `position_id`, `firstname`, `lastname`, `photo`) VALUES
(59, '28DGqAFjZO', 31, 'Rabiul', 'Islam', ''),
(67, 'OvEqUXV64Q', 36, 'Rabiul', 'Islam', 'Picture_300x300.jpg'),
(68, 'OvEqUXV64Q', 36, 'Rakibul', 'Islam', ''),
(69, 'OvEqUXV64Q', 37, 'Sakib', 'Shahon', ''),
(71, 'OvEqUXV64Q', 37, 'Abu', 'Raihan', ''),
(72, 'OZheRHr5In', 38, 'Rakibul', 'Islam', ''),
(73, 'OZheRHr5In', 38, 'Rabiul', 'Islam', ''),
(74, 'OZheRHr5In', 39, 'Sakib', 'Shahon', ''),
(75, 'OZheRHr5In', 39, 'Azizul', 'Islam', ''),
(76, 'OZheRHr5In', 40, 'Abu', 'Raihan', ''),
(77, 'OZheRHr5In', 40, 'Asadul', 'Islam', ''),
(78, '8klr16QnO5', 41, 'Sakib', 'Shahon', ''),
(79, '8klr16QnO5', 41, 'Arafat', 'Hossain', ''),
(80, '8klr16QnO5', 42, 'Azizul', 'Islam', ''),
(81, '8klr16QnO5', 42, 'Abu', 'Raihan', '');

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `id` int(10) NOT NULL,
  `election_id` varchar(20) DEFAULT NULL,
  `election_name` varchar(40) NOT NULL,
  `endtime` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`id`, `election_id`, `election_name`, `endtime`) VALUES
(52, 'OvEqUXV64Q', 'CR Election-2022', '2022-04-04T09:44'),
(60, 'OZheRHr5In', 'Union Council Election-2022', '2022-04-04T09:44'),
(62, 'BtSvNYobmK', 'CR-election-3', '2022-04-04T09:44'),
(65, 'GYb8IPOsUi', 'CR-election-3', NULL),
(66, '8klr16QnO5', 'CR-election-4', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `max_vote` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `election_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `description`, `max_vote`, `priority`, `election_id`) VALUES
(31, 'President', 1, 1, '28DGqAFjZO'),
(36, 'President', 1, 1, 'OvEqUXV64Q'),
(37, 'Vice-President', 1, 2, 'OvEqUXV64Q'),
(38, 'President', 1, 1, 'OZheRHr5In'),
(39, 'Vice-President', 1, 2, 'OZheRHr5In'),
(40, 'Member', 1, 3, 'OZheRHr5In'),
(41, 'President', 1, 1, '8klr16QnO5'),
(42, 'Vice-President', 1, 2, '8klr16QnO5');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `voters_id` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `email` varchar(225) NOT NULL,
  `election_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `voters_id`, `password`, `firstname`, `lastname`, `photo`, `email`, `election_id`) VALUES
(77, 'GUw6C', 'nc1k9', 'Rabiul', 'Islam', 'Picture_300x300.jpg', 'rabiulislam12362@gmail.com', 'OvEqUXV64Q'),
(78, 'MoNx6', 'BFImV', 'Rakibul', 'Islam', '', 'rakibul162586@gmail.com', 'OvEqUXV64Q'),
(79, 'Jo3a9', 'xzWDE', 'Azizul', 'Islam', '', '2040azizulislam@gmail.com', 'OvEqUXV64Q'),
(80, 'l73zO', 'yU91S', 'Sakib', 'Shahon', '', 'rabiulislam12360@gmail.com', 'OvEqUXV64Q'),
(81, 'dSnGm', 'dx7m9', 'Abu', 'Raihan', '', 'aburaihan50017@gmail.com', 'OvEqUXV64Q'),
(82, '2AzWN', 'mECxP', 'Sakib', 'Shahon', '', 'rabiulislam12362@gmail.com', 'OZheRHr5In'),
(83, 'vNw4f', 'qLEwZ', 'Azizul', 'Islam', '', '2040azizulislam@gmail.com', 'OZheRHr5In'),
(84, 'E9zBv', 'zh5Gq', 'Rabiul', 'Islam', '', 'rabiulislam12362@gmail.com', 'OZheRHr5In'),
(85, 'k37wj', 'aIiTr', 'Rakibul', 'Islam', '', 'rakibul162586@gmail.com', 'OZheRHr5In'),
(86, 'mVUHk', 'IzXGq', 'Arafat', 'Hossain', '', 'rabiulislam12362@gmail.com', 'OZheRHr5In'),
(87, 'Ne4Wk', 'qJMp2', 'Abu', 'Raihan', '', 'aburaihan50017@gmail.com', 'OZheRHr5In'),
(88, 'JOSU9', 'qLg15', 'Rakibul', 'Islam', '', 'rakibul162586@gmail.com', 'BtSvNYobmK'),
(89, 'OVc6p', 'Bi8D2', 'Rabiul', 'Islam', '', 'rabiulislam12362@gmail.com', '8klr16QnO5'),
(90, '2N9Jm', '7Wjln', 'Rakibul', 'Islam', '', 'rakibul162586@gmail.com', '8klr16QnO5');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `voters_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `election_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `voters_id`, `candidate_id`, `position_id`, `election_id`) VALUES
(166, 77, 67, 36, 'OvEqUXV64Q'),
(167, 77, 69, 37, 'OvEqUXV64Q'),
(168, 78, 68, 36, 'OvEqUXV64Q'),
(169, 78, 71, 37, 'OvEqUXV64Q'),
(170, 79, 67, 36, 'OvEqUXV64Q'),
(171, 79, 69, 37, 'OvEqUXV64Q'),
(172, 82, 72, 38, 'OZheRHr5In'),
(173, 82, 74, 39, 'OZheRHr5In'),
(174, 82, 76, 40, 'OZheRHr5In'),
(175, 83, 72, 38, 'OZheRHr5In'),
(176, 83, 75, 39, 'OZheRHr5In'),
(177, 83, 77, 40, 'OZheRHr5In'),
(178, 84, 73, 38, 'OZheRHr5In'),
(179, 84, 74, 39, 'OZheRHr5In'),
(180, 84, 76, 40, 'OZheRHr5In'),
(181, 89, 78, 41, '8klr16QnO5'),
(182, 89, 80, 42, '8klr16QnO5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `election`
--
ALTER TABLE `election`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `election_id` (`election_id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `election`
--
ALTER TABLE `election`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
